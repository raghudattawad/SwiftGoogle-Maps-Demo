//
//  ViewController.swift
//  GoogleMapsDemo
//
//  Created by Raghavendra Dattawad on 12/20/17.
//  Copyright © 2017 Raghavendra Dattawad. All rights reserved.
//

import UIKit
import GoogleMaps

class ViewController: UIViewController,CLLocationManagerDelegate,GMSMapViewDelegate{

    let marker: GMSMarker? = GMSMarker ()
     var locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    
       GMSServices.provideAPIKey("AIzaSyBeLo_dLfpNoOirqwotKDNB3dvXuBQTNzY")
//
//        let camera = GMSCameraPosition.camera(withLatitude: 12.949791, longitude: 77.621686, zoom: 15.0)
//
//
//
//        let mapView = GMSMapView.map(withFrame:CGRect.zero, camera: camera)
//
//        view = mapView
//
//        // Creates a marker in the center of the map.
//        let marker = GMSMarker()
//        marker.position = CLLocationCoordinate2D(latitude: 12.949791, longitude: 77.621686)
//        marker.title = "Bangalore"
//        marker.snippet = "karanataka"
//        marker.map = mapView
//        let markerImage = UIImage(named: "icon")!.withRenderingMode(.alwaysTemplate)
//
//        let markerView = UIImageView(image: markerImage)
//
//        //changing the tint color of the image
//        markerView.tintColor = UIColor.green
//
//        marker.iconView = markerView
//
////        if CLLocationManager.locationServicesEnabled() {
////            locationManager.startUpdatingLocation() // start location manager
////
////        }
//
//      //  CLLocationManager.startUpdatingLocation()
//
//        //CLLocationManager.startUpdatingLocation()
//
//        if CLLocationManager.locationServicesEnabled() {
//            print("Yes")
//
//        }
//
//        locationManager.delegate = self
//    locationManager.startUpdatingLocation()
//
//    }
//
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.startUpdatingLocation()
    
    
    
   
    
    
    
    }
//   func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
//   {
//
//
//    if marker == nil {
//
//
//
//       let userLocation = locations.last
//
//      let center = CLLocationCoordinate2D(latitude: userLocation!.coordinate.latitude, longitude: userLocation!.coordinate.longitude)
//
//       let camera = GMSCameraPosition.camera(withLatitude: userLocation!.coordinate.latitude,
//                                                          longitude: userLocation!.coordinate.longitude, zoom: 8)
//      let mapView = GMSMapView.map(withFrame: CGRect.zero, camera: camera)
//       mapView.isMyLocationEnabled = true
//      self.view = mapView
//      // let marker = GMSMarker()
//    marker?.position = center
//    marker?.title = "Bangalore"
//    marker?.snippet = "jayanagr"
//    marker?.icon =   UIImage(named: "icon")
//
//        marker?.map = mapView
//
//
//
//
//      locationManager.stopUpdatingLocation()
//
//   }
//
//    func mapView(_ mapView: GMSMapView, didChange position: GMSCameraPosition) {
//
//
//
//    }
//
//
//
//}
    func updateCoordinates(coordinates:CLLocationCoordinate2D){
        
        if marker == nil {
           
            marker?.position =  coordinates
            
            let image = UIImage(named:"icon")
            marker?.icon = image
            //marker?.map =
            
            
            
            
            
            
           
        }
        
        
        
        
    }


}

func mapView(mapView: GMSMapView, didEndDraggingMarker marker: GMSMarker)
{
//    let destinationLocation = CLLocation()
//    if marker.userData as! String == "changedestination"
//    {
//        self.destinationLocation = CLLocation(latitude: marker.position.latitude, longitude: marker.position.longitude)
//        self.destinationCoordinate = self.destinationLocation.coordinate
//        getAddressFromLatLong(destinationCoordinate)
//
//        let center = CLLocationCoordinate2D(latitude: userLocation!.coordinate.latitude, longitude: userLocation!.coordinate.longitude)
//
//        let camera = GMSCameraPosition.camera(withLatitude: userLocation!.coordinate.latitude,
//                                              longitude: userLocation!.coordinate.longitude, zoom: 8)
//
//    }
}


